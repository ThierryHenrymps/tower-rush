#!/usr/bin/env python3
"""
Tower Rush - identidade sonora 100% sintetizada.
Nenhum sample, gravação ou melodia de terceiros: todo som nasce de ondas
senoidais, ruído e filtros calculados com NumPy/SciPy.

Uso:  python3 generate_audio.py   (gera os 4 .wav na mesma pasta do script)
"""
import os
import wave
import numpy as np
from scipy import signal

SR = 44100
rng = np.random.default_rng(2026)
OUT = os.path.dirname(os.path.abspath(__file__))


# ----------------------------------------------------------------- utilidades
def mtof(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def t_arr(d):
    return np.arange(int(d * SR)) / SR


def fade_out(s, secs):
    s = s.copy()
    n = min(int(secs * SR), len(s))
    s[-n:] *= np.cos(np.linspace(0, np.pi / 2, n)) ** 2
    return s


def fade_in(s, secs):
    s = s.copy()
    n = min(int(secs * SR), len(s))
    s[:n] *= np.sin(np.linspace(0, np.pi / 2, n)) ** 2
    return s


def norm(s):
    m = np.max(np.abs(s))
    return s / m if m > 0 else s


def lp(x, fc, order=2):
    sos = signal.butter(order, fc / (SR / 2), "low", output="sos")
    return signal.sosfilt(sos, x)


def hp(x, fc, order=2):
    sos = signal.butter(order, fc / (SR / 2), "high", output="sos")
    return signal.sosfilt(sos, x)


class Buf:
    """Buffer estéreo com mixagem por posição (s) e pan (-1..1)."""

    def __init__(self, dur):
        self.n = int(dur * SR)
        self.l = np.zeros(self.n)
        self.r = np.zeros(self.n)

    def add(self, sig, t, pan=0.0, gain=1.0):
        i = max(int(round(t * SR)), 0)
        if i >= self.n:
            return
        m = min(len(sig), self.n - i)
        ang = (pan + 1) * np.pi / 4
        self.l[i:i + m] += sig[:m] * np.cos(ang) * gain
        self.r[i:i + m] += sig[:m] * np.sin(ang) * gain


def make_ir(rt60, damp, seed):
    r = np.random.default_rng(seed)
    n = int(rt60 * 1.1 * SR)
    t = np.arange(n) / SR
    ir = r.standard_normal(n) * np.exp(-6.9 * t / rt60)
    ir = lp(ir, damp, 1)
    k = int(0.015 * SR)
    ir[:k] *= np.linspace(0, 1, k)
    return ir / np.sqrt(np.sum(ir ** 2))


def reverb(l, r, rt60, mix, damp=5000, predelay=0.012, seed=1):
    outs = []
    for ch, x in enumerate((l, r)):
        ir = np.concatenate([np.zeros(int(predelay * SR)),
                             make_ir(rt60, damp, seed + 17 * ch)])
        outs.append((x, signal.fftconvolve(x, ir)))
    n = len(outs[0][1])
    res = []
    for x, w in outs:
        y = mix * w
        y[:len(x)] += x
        res.append(y)
    return res[0], res[1]


def fold(y, n):
    """Dobra a cauda de reverb/notas sobre o início => loop circular perfeito."""
    out = np.zeros(n)
    for i in range(0, len(y), n):
        c = y[i:i + n]
        out[:len(c)] += c
    return out


def save_wav(path, l, r, peak_db):
    st = np.stack([l, r], axis=1)
    st = st / np.max(np.abs(st)) * 10 ** (peak_db / 20)
    data = (np.clip(st, -1, 1) * 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())


# ------------------------------------------------------------------- vozes
def bell(f, ring=1.0, dur=None):
    """Sino/glockenspiel cristalino: parciais inarmônicos."""
    ratios = [1, 2.0, 2.76, 5.40, 8.93]
    amps = [1, .35, .5, .22, .12]
    taus = [1.5, 1.0, .75, .33, .18]
    dur = dur or 5 * 1.5 * ring
    t = t_arr(dur)
    s = np.zeros_like(t)
    for r_, a, tau in zip(ratios, amps, taus):
        fr = f * r_
        if fr > SR * 0.42:
            continue
        s += a * np.sin(2 * np.pi * fr * t + rng.uniform(0, 6.28)) * np.exp(-t / (tau * ring))
    s = fade_in(s, 0.002)
    s = fade_out(s, dur * 0.3)
    return norm(s)


def piano(f, dur=3.5, vel=0.7):
    """Piano suave aditivo: cordas duplas levemente desafinadas + martelo."""
    t = t_arr(dur)
    s = np.zeros_like(t)
    base = 2.2 * (261.6 / f) ** 0.35
    for k in range(1, 11):
        fk = k * f * np.sqrt(1 + 0.0004 * k * k)
        if fk > SR * 0.42:
            break
        a = 1 / k ** 1.1
        tau = base / (1 + 0.5 * (k - 1))
        s += a * np.exp(-t / tau) * 0.5 * (np.sin(2 * np.pi * fk * t) +
                                           np.sin(2 * np.pi * fk * 1.0006 * t + 1.0))
    h = rng.standard_normal(len(t)) * np.exp(-t / 0.006)
    s += 0.08 * lp(h, 2500)
    s = lp(s, 1800 + 3500 * vel)
    s = fade_in(s, 0.004)
    s = fade_out(s, 0.5)
    return norm(s) * vel


def pad_voice(f, dur, detune):
    t = t_arr(dur)
    ff = f * 2 ** (detune / 1200)
    ph = rng.uniform(0, 6.28)
    v = np.zeros_like(t)
    for k in range(1, 7):
        v += np.sin(2 * np.pi * ff * k * t + ph * k) / k ** 2
    lfo = 1 + 0.08 * np.sin(2 * np.pi * 0.2 * t + ph)
    att, rel = 0.9, 1.3
    env = np.minimum(1, t / att) ** 2 * np.minimum(1, (dur - t) / rel) ** 2
    return norm(v * lfo * env)


def pluck(f, dur=0.6, tau0=0.25):
    t = t_arr(dur)
    s = np.zeros_like(t)
    for k in range(1, 7):
        if f * k > SR * 0.42:
            break
        s += (1 / k) * np.sin(2 * np.pi * f * k * t) * np.exp(-t / (tau0 / (1 + 0.4 * (k - 1))))
    s = fade_in(s, 0.003)
    s = fade_out(s, dur * 0.25)
    return norm(lp(s, 7000))


def noise_burst(dur, tau, hp_fc=1500):
    t = t_arr(dur)
    n = hp(rng.standard_normal(len(t)), hp_fc) * np.exp(-t / tau)
    return fade_in(norm(n), 0.001)


PENTA = [84, 86, 88, 91, 93, 96, 98, 100]   # C D E G A (oitavas altas)


# ------------------------------------------------------------ 1. block_place
def block_place():
    D = 0.7
    b = Buf(D)
    t = t_arr(0.32)
    # "thump" macio: pitch cai
    f1 = 85 + 95 * np.exp(-t / 0.03)
    thump = np.sin(2 * np.pi * np.cumsum(f1) / SR) * np.exp(-t / 0.075)
    # "plup": pitch sobe rapidamente (efeito de bolha/gota)
    f2 = 520 - 250 * np.exp(-t / 0.022)
    pop = np.sin(2 * np.pi * np.cumsum(f2) / SR) * np.exp(-t / 0.055)
    pop += 0.2 * np.sin(2 * np.pi * np.cumsum(f2) * 2 / SR) * np.exp(-t / 0.02)
    click = lp(rng.standard_normal(len(t)), 3000) * np.exp(-t / 0.003)
    s = 0.8 * norm(thump) + 0.7 * norm(pop) + 0.12 * norm(click)
    s = lp(s, 4500)
    s = fade_in(s, 0.002)
    b.add(s, 0.0)
    l, r = reverb(b.l, b.r, 0.28, 0.18, damp=3500, predelay=0.004, seed=3)
    l, r = l[:int(D * SR)], r[:int(D * SR)]
    return fade_out(l, 0.15), fade_out(r, 0.15)


# ----------------------------------------------------------- 2. magic_event
def magic_event():
    D = 3.6
    b = Buf(D)
    # sobe-e-brilha: vozes com glissando exponencial
    rise_d = 0.65
    t = t_arr(rise_d)
    sw = np.zeros_like(t)
    for m, base in enumerate([500, 750, 1000, 1500]):
        f = base * 6 ** (t / rise_d)
        ph = 2 * np.pi * np.cumsum(f) / SR + m
        sw += np.sin(ph) * (0.8 + 0.2 * np.sin(2 * np.pi * (7 + m) * t))
    sw = norm(sw) * (t / rise_d) ** 1.5
    sw = lp(sw, 9000)
    b.add(fade_out(sw, 0.05), 0.0, gain=0.22)
    air = hp(rng.standard_normal(len(t)), 3500) * (t / rise_d) ** 2.2
    b.add(fade_out(norm(air), 0.05), 0.0, gain=0.16)
    # arpejo de sinos ascendente
    for i, m in enumerate(PENTA):
        b.add(bell(mtof(m), ring=0.9), 0.075 * i, pan=-0.6 + 0.17 * i, gain=0.42)
    # pequena explosão de energia
    t0 = 0.64
    tt = t_arr(0.5)
    fb = 55 + 170 * np.exp(-tt / 0.04)
    thump = np.sin(2 * np.pi * np.cumsum(fb) / SR) * np.exp(-tt / 0.13)
    b.add(fade_out(norm(thump), 0.1), t0, gain=0.55)
    b.add(noise_burst(0.6, 0.11, 1800), t0, gain=0.5)
    for j, m in enumerate([84, 88, 91, 96]):
        b.add(bell(mtof(m), ring=1.3), t0, pan=(-0.5 + 0.33 * j), gain=0.45)
    # faíscas cintilantes
    times = np.sort(rng.uniform(0.05, 1.5, 18)) + t0
    for k, tm in enumerate(times):
        m = int(rng.choice(PENTA)) 
        b.add(bell(mtof(m), ring=0.6), tm, pan=rng.uniform(-0.9, 0.9),
              gain=0.28 * (1 - k / 22))
    l, r = reverb(hp(b.l, 120), hp(b.r, 120), 1.6, 0.32, damp=7000, seed=11)
    n = int(D * SR)
    return fade_out(l[:n], 0.4), fade_out(r[:n], 0.4)


# ----------------------------------------------------------- 3. new_record
def new_record():
    D = 3.2
    b = Buf(D)
    run = [72, 76, 79, 84, 88]            # C5 E5 G5 C6 E6
    for i, m in enumerate(run):
        b.add(pluck(mtof(m), 0.5, 0.2), 0.085 * i, pan=-0.4 + 0.2 * i, gain=0.55)
        b.add(bell(mtof(m + 12), ring=0.5), 0.085 * i, pan=-0.4 + 0.2 * i, gain=0.18)
    b.add(pluck(mtof(91), 0.45, 0.2), 0.52, pan=0.3, gain=0.55)        # G6
    tf = 0.66                                                          # acorde final
    for j, m in enumerate([60, 72, 79, 84, 88]):
        b.add(pluck(mtof(m), 1.8, 0.65), tf, pan=-0.5 + 0.25 * j, gain=0.5)
    b.add(pluck(mtof(96), 1.4, 0.45), tf, gain=0.45)                   # C7
    for j, m in enumerate([96, 100, 103]):
        b.add(bell(mtof(m), ring=1.2), tf + 0.02 * j, pan=-0.3 + 0.3 * j, gain=0.3)
    for k, tm in enumerate(np.sort(rng.uniform(0.1, 1.5, 12)) + tf):
        b.add(bell(mtof(int(rng.choice(PENTA))), ring=0.55), tm,
              pan=rng.uniform(-0.9, 0.9), gain=0.2 * (1 - k / 16))
    l, r = reverb(hp(b.l, 100), hp(b.r, 100), 1.4, 0.26, damp=7000, seed=21)
    n = int(D * SR)
    return fade_out(l[:n], 0.5), fade_out(r[:n], 0.5)


# ------------------------------------------------------- 4. background_music
def background_music():
    BPM = 84
    beat = 60 / BPM
    bar = 4 * beat
    BARS = 16
    N = int(round(BARS * bar * SR))
    TAIL = 6.0
    dur_total = BARS * bar + TAIL

    # acorde por compasso: baixo, arpejo (4 notas) e pad
    chords = [
        dict(root=36, arp=[55, 59, 62, 64], pad=[59, 62, 64, 67]),   # Cmaj9
        dict(root=40, arp=[55, 59, 62, 67], pad=[59, 62, 67, 71]),   # Em7
        dict(root=41, arp=[57, 60, 64, 71], pad=[60, 64, 69, 71]),   # Fmaj7#11
        dict(root=43, arp=[55, 59, 62, 69], pad=[59, 62, 67, 69]),   # Gadd9
        dict(root=45, arp=[57, 60, 64, 67], pad=[60, 64, 67, 71]),   # Am9
        dict(root=40, arp=[55, 59, 62, 67], pad=[59, 62, 67, 71]),   # Em7
        dict(root=41, arp=[57, 60, 64, 69], pad=[60, 64, 67, 69]),   # Fmaj7(6/9)
        dict(root=43, arp=[55, 60, 62, 67], pad=[60, 62, 67, 69]),   # Gsus4
    ]
    # melodia original (pentatônica de Dó): (tempo, nota MIDI, duração em tempos)
    melody = [
        [(0, 76, 1.5), (1.5, 79, .5), (2, 81, 1), (3, 79, 1)],
        [(0, 76, 2), (2, 74, 1), (3, 76, 1)],
        [(0, 81, 1.5), (1.5, 79, .5), (2, 76, 2)],
        [(0, 74, 1), (1, 76, 1), (2, 79, 2)],
        [(0, 81, 2), (2, 84, 1), (3, 81, 1)],
        [(0, 79, 1.5), (1.5, 76, .5), (2, 74, 1), (3, 76, 1)],
        [(0, 74, 1.5), (1.5, 76, .5), (2, 79, 2)],
        [(0, 81, 1), (1, 79, 1), (2, 74, 2)],
        # segunda volta (variação)
        [(0, 79, 1), (1, 81, 1), (2, 84, 2)],
        [(0, 83, 1.5), (1.5, 81, .5), (2, 79, 2)],
        [(0, 84, 1), (1, 81, 1), (2, 79, 1), (3, 76, 1)],
        [(0, 79, 1.5), (1.5, 81, .5), (2, 79, 1), (3, 74, 1)],
        [(0, 76, 1), (1, 79, 1), (2, 81, 2)],
        [(0, 79, 2), (2, 76, 2)],
        [(0, 81, 1), (1, 79, 1), (2, 76, 1), (3, 74, 1)],
        [(0, 72, 1), (1, 74, 1), (2, 79, 2)],
    ]

    stems = {k: Buf(dur_total) for k in ["arp", "mel", "pad", "bass", "bell", "shk"]}
    jit = lambda: rng.uniform(-0.008, 0.008)

    for b in range(BARS):
        c = chords[b % 8]
        t0 = b * bar
        # pad
        for m in c["pad"]:
            for d, p in zip((-7, 0, 7), (-0.6, 0.0, 0.6)):
                stems["pad"].add(pad_voice(mtof(m), bar + 1.6, d), t0, pan=p)
        # baixo
        tb = t_arr(3.4 * beat + 0.4)
        bs = np.sin(2 * np.pi * mtof(c["root"]) * tb) + 0.3 * np.sin(2 * np.pi * 2 * mtof(c["root"]) * tb)
        bs = fade_out(fade_in(bs * np.exp(-tb / 1.6), 0.03), 0.4)
        stems["bass"].add(norm(bs), t0)
        # arpejo de colcheias
        pat = [0, 1, 2, 3, 2, 1, 3, 2]
        for i, idx in enumerate(pat):
            vel = (0.5 if i % 4 == 0 else 0.38) * rng.uniform(0.9, 1.1)
            stems["arp"].add(piano(mtof(c["arp"][idx]), 2.4, vel),
                             t0 + i * beat / 2 + jit(), pan=-0.25 + 0.1 * idx)
        # shaker bem leve nos contratempos
        for i in range(8):
            if i % 2 == 1:
                stems["shk"].add(noise_burst(0.12, 0.025, 6000), t0 + i * beat / 2 + jit(),
                                 pan=0.3, gain=0.5 * rng.uniform(0.8, 1.0))
        # melodia + sinos dobrados
        for (bt, m, d) in melody[b]:
            tt = t0 + bt * beat + jit() * 1.5
            stems["mel"].add(piano(mtof(m), 3.4, 0.68 * rng.uniform(0.92, 1.05)), tt, pan=0.12)
            if b >= 8:
                stems["bell"].add(bell(mtof(m + 12), ring=0.8), tt + 0.01, pan=0.4, gain=0.55)
        # faíscas de sino (esparsas na 1ª volta, mais frequentes na 2ª)
        spots = [3.5] if b < 8 and b % 2 == 0 else ([1.5, 3.5] if b >= 8 else [])
        for sp in spots:
            m = int(rng.choice(PENTA))
            stems["bell"].add(bell(mtof(m), ring=0.9), t0 + sp * beat,
                               pan=rng.uniform(-0.7, 0.7), gain=0.3)

    gains = dict(arp=0.55, mel=0.95, pad=0.16, bass=0.34, bell=0.22, shk=0.035)
    L = np.zeros(stems["arp"].n)
    R = np.zeros(stems["arp"].n)
    for k, bf in stems.items():
        gl, gr = bf.l, bf.r
        if k == "pad":
            gl, gr = lp(gl, 2200), lp(gr, 2200)
        L += gl * gains[k]
        R += gr * gains[k]

    L, R = hp(L, 35), hp(R, 35)
    L, R = lp(L, 11000), lp(R, 11000)
    L, R = reverb(L, R, 2.6, 0.38, damp=4500, seed=31)
    L, R = fold(L, N), fold(R, N)          # loop circular sem emendas
    g = 0.7 / max(np.max(np.abs(L)), np.max(np.abs(R)))   # normaliza antes do limitador suave
    L, R = np.tanh(L * g * 1.1), np.tanh(R * g * 1.1)
    return L, R


if __name__ == "__main__":
    jobs = [
        ("block_place.wav", block_place, -4.0),
        ("magic_event.wav", magic_event, -2.5),
        ("new_record.wav", new_record, -2.5),
        ("background_music.wav", background_music, -8.0),
    ]
    for name, fn, pk in jobs:
        l, r = fn()
        save_wav(os.path.join(OUT, name), l, r, pk)
        print(f"{name}: {len(l) / SR:.2f}s")
