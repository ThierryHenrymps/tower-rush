#!/usr/bin/env python3
"""
water_splash.wav - respingo de água 100% sintetizado (ruído filtrado + senoides).
Sem samples nem gravações de terceiros.   Uso: python3 generate_water_splash.py
"""
import os, wave
import numpy as np
from scipy import signal

SR = 44100
rng = np.random.default_rng(404)
OUT = os.path.dirname(os.path.abspath(__file__))


def t_arr(d): return np.arange(int(d * SR)) / SR
def sos(x, fc, kind, order=2):
    return signal.sosfilt(signal.butter(order, np.array(fc) / (SR / 2), kind, output="sos"), x)
def fade(s, a=0.002, b=0.0):
    s = s.copy()
    n = int(a * SR); s[:n] *= np.linspace(0, 1, n)
    if b:
        m = int(b * SR); s[-m:] *= np.cos(np.linspace(0, np.pi / 2, m)) ** 2
    return s


D = 1.8
N = int(D * SR)
L = np.zeros(N); R = np.zeros(N)


def add(sig, t, pan=0.0, g=1.0):
    i = int(t * SR); m = min(len(sig), N - i)
    if m <= 0: return
    a = (pan + 1) * np.pi / 4
    L[i:i + m] += sig[:m] * np.cos(a) * g
    R[i:i + m] += sig[:m] * np.sin(a) * g


# 1) impacto: corpo de ruído passa-banda + "tum" grave de água
t = t_arr(0.6)
body = sos(sos(rng.standard_normal(len(t)), 3800, "low"), 250, "high") * np.exp(-t / 0.11)
add(fade(body / np.abs(body).max(), 0.006), 0.0, g=0.85)
tt = t_arr(0.4)
thump = np.sin(2 * np.pi * np.cumsum(60 + 140 * np.exp(-tt / 0.035)) / SR) * np.exp(-tt / 0.09)
add(fade(thump, 0.004, 0.1), 0.0, g=0.5)

# 2) borrifo (spray) agudo que se espalha
t = t_arr(0.9)
spray = sos(rng.standard_normal(len(t)), 2600, "high") * np.exp(-t / 0.22) * (1 - np.exp(-t / 0.03))
add(fade(spray / np.abs(spray).max(), 0.01, 0.2), 0.02, g=0.4)

# 3) bolhas: senoides cujo pitch SOBE enquanto decaem (assinatura de "bloop")
for k, tm in enumerate(np.sort(rng.uniform(0.04, 0.75, 8))):
    f0 = rng.uniform(450, 1300)
    tb = t_arr(0.16)
    f = f0 * (1 + 3.2 * tb)
    b = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tb / (0.032 * (900 / f0) ** 0.5))
    add(fade(b, 0.002, 0.04), tm, pan=rng.uniform(-0.7, 0.7), g=0.34 * (1 - k / 11))

# 4) gotinhas caindo ("plinks" agudos)
for k, tm in enumerate(np.sort(rng.uniform(0.18, 1.2, 9))):
    f0 = rng.uniform(1800, 3300)
    tb = t_arr(0.08)
    f = f0 * (1 + 4 * tb)
    d = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tb / 0.012)
    add(fade(d, 0.001, 0.02), tm, pan=rng.uniform(-0.9, 0.9), g=0.13 * (1 - k / 13))

# reverb curto de "pia/piscina"
def ir(rt60, seed):
    r = np.random.default_rng(seed); n = int(rt60 * 1.1 * SR); x = np.arange(n) / SR
    h = sos(r.standard_normal(n) * np.exp(-6.9 * x / rt60), 6000, "low", 1)
    h[:int(0.01 * SR)] *= np.linspace(0, 1, int(0.01 * SR))
    return h / np.sqrt((h ** 2).sum())

outs = []
for ch, x in enumerate((L, R)):
    w = signal.fftconvolve(x, ir(0.55, 5 + ch * 9))[:N]
    outs.append(x + 0.22 * w)
L, R = fade(sos(outs[0], 60, "high"), 0.001, 0.35), fade(sos(outs[1], 60, "high"), 0.001, 0.35)

st = np.stack([L, R], 1)
st = st / np.abs(st).max() * 10 ** (-3.5 / 20)
with wave.open(os.path.join(OUT, "water_splash.wav"), "wb") as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((np.clip(st, -1, 1) * 32767).astype("<i2").tobytes())
print("water_splash.wav", D, "s")
